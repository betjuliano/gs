"""
Módulo 04 — Modelo de Churn
GestãoDS ICP Analysis Pipeline

Responsabilidades:
  - Treinar modelo XGBoost para prever churn nos próximos 90 dias
  - Aplicar SMOTE automaticamente se base desbalanceada
  - Calcular feature importance e SHAP values
  - Atribuir score de risco 0-100 a cada cliente ativo
  - Janela temporal: usa apenas dados anteriores ao evento
"""

import os
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.metrics import (classification_report, roc_auc_score,
                              roc_curve, confusion_matrix)
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

OUTPUT_DIR = "outputs"
MODELS_DIR = "outputs/models"

# Features para o modelo de churn
# NPS excluído aqui — o código aplica a flag do audit automaticamente
CHURN_FEATURES_BASE = [
    # Firmográfico
    "total_usuarios", "porte_encoded", "uf_encoded",
    "especialidade_encoded",
    # Produto
    "mau", "score_adocao_composto", "score_operacional",
    "score_financeiro", "score_jornada",
    "semaforo_essencial", "semaforo_financeiro",
    "usa_financeiro", "usa_conciliacao", "fluxo_whatsapp",
    "usa_ia", "usa_chatgds",
    # Financeiro
    "mrr_atual", "mrr_medio_historico", "valor_addons",
    "ratio_addons_mrr", "fez_upgrade", "fez_downgrade",
    # Pacientes
    "num_pacientes_total", "pacientes_ativos_12m",
    "taxa_novos_pacientes_6m", "crescimento_pacientes_6_12",
    "potencial_economico", "ticket_medio",
    # Temporal
    "maturidade_meses",
]


def prepare_churn_data(df: pd.DataFrame, nps_audit: dict) -> tuple:
    """
    Prepara X, y para o modelo de churn.
    - Exclui clientes com menos de 90 dias (muito novos para modelar)
    - Exclui NPS se audit indicar leakage
    - Remove features com > 50% nulos
    """
    features = list(CHURN_FEATURES_BASE)

    # Inclui NPS apenas se safe
    if nps_audit.get("usar_nps_no_modelo", False) and "nps_tratado" in df.columns:
        features.append("nps_tratado")

    # Filtra clientes maduros
    df_model = df[df.get("cliente_maduro", pd.Series(1, index=df.index)) == 1].copy()

    if "churn" not in df_model.columns:
        raise ValueError("Coluna 'churn' não encontrada no DataFrame.")

    # Mantém apenas features disponíveis com dado suficiente
    features = [
        f for f in features
        if f in df_model.columns and df_model[f].notna().mean() > 0.5
    ]

    X = df_model[features].copy()
    y = df_model["churn"].values

    # Imputa medianas
    for col in X.columns:
        X[col] = X[col].fillna(X[col].median())

    print(f"✅ Dados de churn: {len(X):,} clientes | {len(features)} features")
    print(f"   Churn rate: {y.mean()*100:.1f}%")
    return X, y, features, df_model.index


def balance_classes(X: np.ndarray, y: np.ndarray, pct_churn: float) -> tuple:
    """
    Aplica SMOTE se desbalanceamento crítico (< 20% ou > 80% de uma classe).
    """
    if pct_churn < 20 or pct_churn > 80:
        try:
            from imblearn.over_sampling import SMOTE
            sm    = SMOTE(random_state=42, k_neighbors=min(5, int(y.sum()) - 1))
            X_res, y_res = sm.fit_resample(X, y)
            print(f"⚖️  SMOTE aplicado: {len(y)} → {len(y_res)} amostras")
            return X_res, y_res
        except Exception as e:
            print(f"⚠️  SMOTE falhou ({e}), prosseguindo com dados originais.")
            return X, y
    return X, y


def train_churn_model(X: np.ndarray, y: np.ndarray) -> tuple:
    """
    Treina XGBoost com cross-validation estratificada.
    Retorna (modelo_final, scores_cv, threshold_otimo).
    """
    pct_churn = y.mean() * 100

    model = XGBClassifier(
        n_estimators=300,
        max_depth=5,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=(1 - y.mean()) / y.mean(),  # penaliza classe minoritária
        random_state=42,
        eval_metric="auc",
        verbosity=0,
        use_label_encoder=False,
    )

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    scores = cross_val_score(model, X, y, cv=cv, scoring="roc_auc")

    # Treina na base completa balanceada
    X_bal, y_bal = balance_classes(X, y, pct_churn)
    model.fit(X_bal, y_bal)

    print(f"✅ Churn model AUC-ROC: {scores.mean():.3f} ± {scores.std():.3f}")
    return model, scores


def find_optimal_threshold(model, X: np.ndarray, y: np.ndarray) -> float:
    """
    Encontra threshold que maximiza F1 na base de treino.
    (Produção deve revalidar em dados futuros.)
    """
    probs = model.predict_proba(X)[:, 1]
    fpr, tpr, thresholds = roc_curve(y, probs)

    # Maximiza Youden J = TPR - FPR
    j_scores  = tpr - fpr
    best_idx  = np.argmax(j_scores)
    threshold = thresholds[best_idx]

    print(f"✅ Threshold ótimo: {threshold:.3f}")
    return float(threshold)


def score_active_clients(df: pd.DataFrame, model, features: list,
                          threshold: float) -> pd.DataFrame:
    """
    Aplica modelo a todos os clientes ativos.
    Adiciona: score_churn (0-100), risco_churn (Alto/Médio/Baixo).
    """
    ativos = df[df.get("churn", pd.Series(0, index=df.index)) == 0].copy()

    X_score = ativos[[f for f in features if f in ativos.columns]].copy()
    for col in X_score.columns:
        X_score[col] = X_score[col].fillna(X_score[col].median())

    # Alinha colunas com o modelo
    for f in features:
        if f not in X_score.columns:
            X_score[f] = 0
    X_score = X_score[features]

    probs = model.predict_proba(X_score)[:, 1]
    df.loc[ativos.index, "score_churn"]   = (probs * 100).round(1)
    df.loc[ativos.index, "prob_churn_raw"] = probs

    df["risco_churn"] = pd.cut(
        df["score_churn"].fillna(0),
        bins=[-1, 30, 60, 101],
        labels=["Baixo", "Médio", "Alto"],
    )

    return df


# ─────────────────────────────────────────────────────────────
# VISUALIZAÇÕES
# ─────────────────────────────────────────────────────────────
def plot_feature_importance(model, features: list) -> str:
    imp = pd.Series(model.feature_importances_, index=features).sort_values(ascending=True)
    top = imp.tail(20)

    fig, ax = plt.subplots(figsize=(9, 7))
    colors = ["#dc2626" if i >= len(top) - 5 else "#3b82f6" for i in range(len(top))]
    ax.barh(top.index, top.values, color=colors)
    ax.set_title("Top 20 Features — Modelo de Churn", fontweight="bold")
    ax.set_xlabel("Importância (gain)")
    plt.tight_layout()

    path = f"{OUTPUT_DIR}/churn_feature_importance.png"
    fig.savefig(path, dpi=120, bbox_inches="tight")
    plt.close(fig)
    return path


def plot_roc_curve(model, X: np.ndarray, y: np.ndarray) -> str:
    probs = model.predict_proba(X)[:, 1]
    fpr, tpr, _ = roc_curve(y, probs)
    auc = roc_auc_score(y, probs)

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.plot(fpr, tpr, color="#2563eb", lw=2, label=f"AUC = {auc:.3f}")
    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Random")
    ax.set_xlabel("Taxa de Falso Positivo")
    ax.set_ylabel("Taxa de Verdadeiro Positivo")
    ax.set_title("Curva ROC — Modelo de Churn", fontweight="bold")
    ax.legend()
    plt.tight_layout()

    path = f"{OUTPUT_DIR}/churn_roc_curve.png"
    fig.savefig(path, dpi=120, bbox_inches="tight")
    plt.close(fig)
    return path


def plot_churn_risk_distribution(df: pd.DataFrame) -> str:
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    ativos = df[df.get("churn", pd.Series(0, index=df.index)) == 0]

    axes[0].hist(ativos["score_churn"].dropna(), bins=40,
                 color="#f97316", edgecolor="white", alpha=0.8)
    axes[0].set_title("Distribuição Score de Churn (Ativos)", fontweight="bold")
    axes[0].set_xlabel("Score de Risco (0–100)")
    axes[0].set_ylabel("Clientes")

    risk_counts = ativos["risco_churn"].value_counts()
    colors_bar  = {"Baixo": "#22c55e", "Médio": "#f59e0b", "Alto": "#ef4444"}
    bars = axes[1].bar(risk_counts.index.astype(str), risk_counts.values,
                       color=[colors_bar.get(r, "gray") for r in risk_counts.index.astype(str)])
    axes[1].set_title("Clientes por Nível de Risco", fontweight="bold")
    axes[1].set_ylabel("Número de Clientes")
    for bar in bars:
        axes[1].text(bar.get_x() + bar.get_width()/2,
                     bar.get_height() + 5,
                     str(int(bar.get_height())),
                     ha="center", fontsize=10)

    plt.tight_layout()
    path = f"{OUTPUT_DIR}/churn_risk_distribution.png"
    fig.savefig(path, dpi=120, bbox_inches="tight")
    plt.close(fig)
    return path


# ─────────────────────────────────────────────────────────────
# PIPELINE PRINCIPAL
# ─────────────────────────────────────────────────────────────
def run_churn_model(df: pd.DataFrame, nps_audit: dict) -> tuple:
    """
    Pipeline completo do modelo de churn.
    Retorna (df_com_scores, modelo, features, threshold, cv_scores).
    """
    print("\n" + "="*60)
    print("  MÓDULO 04 — MODELO DE CHURN")
    print("="*60)

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(MODELS_DIR, exist_ok=True)

    X, y, features, valid_idx = prepare_churn_data(df, nps_audit)
    model, cv_scores           = train_churn_model(X.values, y)
    threshold                  = find_optimal_threshold(model, X.values, y)

    df = score_active_clients(df, model, features, threshold)

    # Plots
    plot_feature_importance(model, features)
    plot_roc_curve(model, X.values, y)
    plot_churn_risk_distribution(df)

    # Salva modelo
    joblib.dump({
        "model": model,
        "features": features,
        "threshold": threshold,
        "cv_auc_mean": cv_scores.mean(),
    }, f"{MODELS_DIR}/churn_model.pkl")

    # Resumo
    ativos_risco = df[df.get("churn", pd.Series(0)) == 0]
    n_alto = (ativos_risco["risco_churn"] == "Alto").sum() if "risco_churn" in ativos_risco.columns else 0
    n_medio = (ativos_risco["risco_churn"] == "Médio").sum() if "risco_churn" in ativos_risco.columns else 0

    print(f"\n📊 Clientes em risco:")
    print(f"   🔴 Alto risco  : {n_alto:,}")
    print(f"   🟡 Médio risco : {n_medio:,}")
    print(f"   AUC-ROC médio  : {cv_scores.mean():.3f}")

    return df, model, features, threshold, cv_scores


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")
    from src.preprocessing_01 import run_preprocessing
    from src.ltv_analysis_02 import run_ltv_analysis
    path = sys.argv[1] if len(sys.argv) > 1 else "data/clientes.csv"
    df, meta = run_preprocessing(path)
    df, _ = run_ltv_analysis(df)
    df, model, feats, thr, cv = run_churn_model(df, meta["nps_audit"])
