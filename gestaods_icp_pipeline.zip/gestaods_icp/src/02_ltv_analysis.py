"""
Módulo 02 — Análise de LTV, Coortes e Top 25%
GestãoDS ICP Analysis Pipeline

Responsabilidades:
  - Identificar top 25% por LTV realizado
  - Análise de retenção por coorte trimestral
  - Análise de LTV e churn por canal de aquisição (rastreável vs não-rastreável)
  - Exportar perfil detalhado do ICP financeiro
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import os
import warnings
warnings.filterwarnings("ignore")

OUTPUT_DIR = "outputs"


# ─────────────────────────────────────────────────────────────
# 1. TOP 25% POR LTV
# ─────────────────────────────────────────────────────────────
def identify_top_ltv(df: pd.DataFrame, col: str = "ltv_realizado") -> pd.DataFrame:
    """
    Marca os 25% com maior LTV realizado.
    Retorna df com coluna 'top25_ltv' (1 = top 25%).
    """
    threshold = df[col].quantile(0.75)
    df["top25_ltv"]      = (df[col] >= threshold).astype(int)
    df["ltv_quartil"]    = pd.qcut(df[col], q=4, labels=["Q1", "Q2", "Q3", "Q4"],
                                    duplicates="drop")
    df["ltv_percentile"] = df[col].rank(pct=True).round(4)
    print(f"✅ Top 25% LTV: threshold = R$ {threshold:,.2f}")
    return df


# ─────────────────────────────────────────────────────────────
# 2. PERFIL DO ICP (TOP 25%)
# ─────────────────────────────────────────────────────────────
def profile_top_icp(df: pd.DataFrame) -> dict:
    """
    Compara o perfil do top 25% com o restante da base.
    Retorna dicionário com DataFrames de comparação.
    """
    top    = df[df["top25_ltv"] == 1]
    outros = df[df["top25_ltv"] == 0]

    # Métricas numéricas: mediana top vs resto
    numeric_features = [
        "num_medicos", "num_secretarias", "total_usuarios",
        "mau", "score_adocao_composto", "score_operacional",
        "score_financeiro", "score_jornada",
        "mrr_atual", "valor_addons", "ratio_addons_mrr",
        "num_pacientes_total", "pacientes_ativos_12m",
        "ticket_medio", "faturamento_reconciliado",
        "dias_ativo", "anos_ativos",
    ]
    existing = [f for f in numeric_features if f in df.columns]

    comparacao = pd.DataFrame({
        "Top 25% (mediana)":    top[existing].median().round(2),
        "Demais (mediana)":     outros[existing].median().round(2),
        "Diferença %":          (
            (top[existing].median() - outros[existing].median())
            / outros[existing].median().replace(0, np.nan) * 100
        ).round(1),
    })

    # Distribuição por especialidade principal
    esp_top = (
        top["especialidade_principal"].value_counts(normalize=True).head(10) * 100
    ).round(1) if "especialidade_principal" in top.columns else pd.Series()

    # Distribuição por porte
    porte_top = (
        top["porte_clinica"].value_counts(normalize=True) * 100
    ).round(1) if "porte_clinica" in top.columns else pd.Series()

    # Adoção de módulos no top 25%
    modulos = ["usa_financeiro", "usa_conciliacao", "usa_ia",
               "usa_chatgds", "fluxo_whatsapp", "fez_upgrade"]
    adocao = {}
    for m in modulos:
        if m in top.columns:
            adocao[m] = {
                "top25 (%)":  round(top[m].mean() * 100, 1),
                "demais (%)": round(outros[m].mean() * 100, 1),
            }

    # Churn rate no top 25% vs demais
    churn_top    = round(top["churn"].mean() * 100, 1) if "churn" in top.columns else None
    churn_outros = round(outros["churn"].mean() * 100, 1) if "churn" in outros.columns else None

    perfil = {
        "comparacao_numerica": comparacao,
        "especialidades_top":  esp_top,
        "porte_top":           porte_top,
        "adocao_modulos":      pd.DataFrame(adocao).T,
        "churn_top25":         churn_top,
        "churn_demais":        churn_outros,
        "n_top":               len(top),
        "n_demais":            len(outros),
    }

    print(f"✅ Perfil ICP gerado — {len(top)} clientes no top 25%")
    print(f"   Churn top 25%: {churn_top}% | Demais: {churn_outros}%")
    return perfil


# ─────────────────────────────────────────────────────────────
# 3. ANÁLISE DE COORTE
# ─────────────────────────────────────────────────────────────
def cohort_retention(df: pd.DataFrame) -> pd.DataFrame:
    """
    Cria tabela de retenção por coorte trimestral.
    Linha = trimestre de entrada | Coluna = meses após entrada.
    """
    if "cohort_trimestre" not in df.columns or "dias_ativo" not in df.columns:
        print("⚠️  Dados insuficientes para análise de coorte.")
        return pd.DataFrame()

    # Agrupa por coorte
    coorte = df.groupby("cohort_trimestre").agg(
        n_clientes=("id_cliente" if "id_cliente" in df.columns else "churn", "count"),
        dias_medio=("dias_ativo", "mean"),
        mrr_medio=("mrr_atual",  "mean"),
        ltv_medio=("ltv_realizado", "mean"),
        churn_rate=("churn", "mean"),
        top25_rate=("top25_ltv", "mean"),
    ).round(2)

    coorte["meses_medio"]   = (coorte["dias_medio"] / 30).round(1)
    coorte["retencao_pct"]  = ((1 - coorte["churn_rate"]) * 100).round(1)
    coorte = coorte.sort_index()

    print(f"✅ Análise de coorte: {len(coorte)} trimestres")
    return coorte


# ─────────────────────────────────────────────────────────────
# 4. ANÁLISE POR CANAL
# ─────────────────────────────────────────────────────────────
def canal_analysis(df: pd.DataFrame) -> dict:
    """
    Compara LTV, MRR e churn por canal de aquisição.
    Separa base rastreável de não-rastreável para evitar viés.
    """
    results = {}

    for subset_name, subset in [
        ("Base completa", df),
        ("Canal rastreável", df[df.get("canal_rastreavel",
                                        pd.Series(0, index=df.index)) == 1]),
    ]:
        if "canal_origem" not in subset.columns or len(subset) == 0:
            continue

        agg = subset.groupby("canal_origem").agg(
            n_clientes=("churn", "count"),
            ltv_medio=("ltv_realizado", "mean"),
            ltv_mediana=("ltv_realizado", "median"),
            mrr_medio=("mrr_atual", "mean"),
            churn_rate=("churn", "mean"),
            dias_ativo_medio=("dias_ativo", "mean"),
        ).round(2)

        agg["retencao_pct"]   = ((1 - agg["churn_rate"]) * 100).round(1)
        agg["meses_medio"]    = (agg["dias_ativo_medio"] / 30).round(1)
        agg["ranking_ltv"]    = agg["ltv_medio"].rank(ascending=False).astype(int)
        results[subset_name]  = agg.sort_values("ltv_medio", ascending=False)

    return results


# ─────────────────────────────────────────────────────────────
# 5. SEGMENTAÇÃO DE PRECIFICAÇÃO POR PACIENTES
# ─────────────────────────────────────────────────────────────
def pricing_tiers_by_patients(df: pd.DataFrame) -> pd.DataFrame:
    """
    Analisa relação entre tamanho da base de pacientes e MRR/LTV.
    Base para estruturar faixas de precificação por pacientes.
    """
    if "num_pacientes_total" not in df.columns:
        return pd.DataFrame()

    df["faixa_pacientes"] = pd.cut(
        df["num_pacientes_total"].fillna(0),
        bins=[0, 200, 500, 1000, 2500, 5000, 999999],
        labels=["<200", "200-500", "500-1k", "1k-2.5k", "2.5k-5k", "5k+"],
    )

    tiers = df.groupby("faixa_pacientes", observed=True).agg(
        n_clientes=("churn", "count"),
        mrr_mediano=("mrr_atual", "median"),
        ltv_mediano=("ltv_realizado", "median"),
        churn_rate=("churn", "mean"),
        score_adocao=("score_adocao_composto", "median"),
        top25_pct=("top25_ltv", "mean"),
    ).round(2)

    tiers["retencao_pct"] = ((1 - tiers["churn_rate"]) * 100).round(1)
    tiers["top25_pct"]    = (tiers["top25_pct"] * 100).round(1)

    print(f"✅ Análise de tiers por pacientes concluída")
    return tiers


# ─────────────────────────────────────────────────────────────
# 6. VISUALIZAÇÕES
# ─────────────────────────────────────────────────────────────
def _save_fig(fig, name: str):
    path = os.path.join(OUTPUT_DIR, name)
    fig.savefig(path, bbox_inches="tight", dpi=120)
    plt.close(fig)
    return path


def plot_ltv_distribution(df: pd.DataFrame) -> str:
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    # Distribuição LTV
    axes[0].hist(df["ltv_realizado"].clip(0, df["ltv_realizado"].quantile(0.95)),
                 bins=40, color="#2563eb", alpha=0.7, edgecolor="white")
    axes[0].set_title("Distribuição LTV Realizado", fontweight="bold")
    axes[0].set_xlabel("LTV (R$)")
    axes[0].set_ylabel("Clientes")

    # LTV por porte
    if "porte_clinica" in df.columns:
        porte_ltv = df.groupby("porte_clinica", observed=True)["ltv_realizado"].median().sort_values()
        axes[1].barh(porte_ltv.index.astype(str), porte_ltv.values, color="#16a34a")
        axes[1].set_title("LTV Mediano por Porte", fontweight="bold")
        axes[1].set_xlabel("LTV Mediano (R$)")

    fig.suptitle("Análise de LTV — GestãoDS", fontsize=13, fontweight="bold")
    plt.tight_layout()
    return _save_fig(fig, "ltv_distribution.png")


def plot_cohort_heatmap(coorte: pd.DataFrame) -> str:
    if coorte.empty:
        return ""
    fig, ax = plt.subplots(figsize=(12, max(4, len(coorte) * 0.4)))
    pivot = coorte[["retencao_pct", "ltv_medio", "mrr_medio"]].T
    sns.heatmap(pivot, annot=True, fmt=".1f", cmap="YlGn",
                linewidths=0.5, ax=ax, cbar_kws={"shrink": 0.6})
    ax.set_title("Métricas por Coorte Trimestral", fontweight="bold")
    plt.tight_layout()
    return _save_fig(fig, "cohort_heatmap.png")


def plot_canal_comparison(canal_data: dict) -> str:
    key = "Canal rastreável" if "Canal rastreável" in canal_data else list(canal_data.keys())[0]
    data = canal_data.get(key, pd.DataFrame())
    if data.empty:
        return ""

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))

    canais = data.index.astype(str)
    axes[0].barh(canais, data["ltv_medio"], color="#7c3aed")
    axes[0].set_title("LTV Médio por Canal", fontweight="bold")
    axes[0].set_xlabel("LTV Médio (R$)")

    colors = ["#ef4444" if c > 30 else "#22c55e" for c in data["churn_rate"] * 100]
    axes[1].barh(canais, data["churn_rate"] * 100, color=colors)
    axes[1].set_title("Churn Rate % por Canal", fontweight="bold")
    axes[1].set_xlabel("Churn (%)")
    axes[1].axvline(x=20, color="orange", linestyle="--", alpha=0.7, label="20% threshold")
    axes[1].legend()

    fig.suptitle("Análise de Canal de Aquisição", fontsize=13, fontweight="bold")
    plt.tight_layout()
    return _save_fig(fig, "canal_comparison.png")


# ─────────────────────────────────────────────────────────────
# 7. PIPELINE PRINCIPAL
# ─────────────────────────────────────────────────────────────
def run_ltv_analysis(df: pd.DataFrame) -> tuple:
    """
    Executa análise completa de LTV, coortes e canais.
    Retorna (df_enriquecido, results_dict).
    """
    print("\n" + "="*60)
    print("  MÓDULO 02 — ANÁLISE DE LTV E RETENÇÃO")
    print("="*60)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    df           = identify_top_ltv(df)
    perfil       = profile_top_icp(df)
    coorte       = cohort_retention(df)
    canais       = canal_analysis(df)
    tiers        = pricing_tiers_by_patients(df)

    # Plots
    plot_ltv_distribution(df)
    plot_cohort_heatmap(coorte)
    if canais:
        plot_canal_comparison(canais)

    results = {
        "perfil_icp":   perfil,
        "coorte":       coorte,
        "canais":       canais,
        "pricing_tiers": tiers,
    }

    print("\n✅ Módulo 02 concluído.")
    return df, results


if __name__ == "__main__":
    import sys
    sys.path.insert(0, "src")
    from src.preprocessing_01 import run_preprocessing
    path = sys.argv[1] if len(sys.argv) > 1 else "data/clientes.csv"
    df, _ = run_preprocessing(path)
    df, res = run_ltv_analysis(df)
    print(res["coorte"])
