"""
Módulo 03 — Segmentação ICP (Clustering)
GestãoDS ICP Analysis Pipeline

Responsabilidades:
  - Selecionar e normalizar features para clustering
  - Determinar número ideal de clusters (método do cotovelo + silhouette)
  - Rodar K-Means e interpretar segmentos
  - Rotular automaticamente cada cluster com perfil descritivo
  - Exportar visualizações 2D (PCA)
"""

import os
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
import warnings
warnings.filterwarnings("ignore")

OUTPUT_DIR  = "outputs"
MODELS_DIR  = "outputs/models"

# Features usadas no clustering — cobrindo as 3 dimensões do "triângulo de ouro"
CLUSTER_FEATURES = [
    # Firmográfico
    "total_usuarios", "porte_encoded",
    # Produto / Adoção
    "score_adocao_composto", "mau", "usa_financeiro",
    "usa_conciliacao", "usa_ia", "usa_chatgds",
    "semaforo_essencial", "semaforo_financeiro",
    # Econômico
    "mrr_atual", "valor_addons", "ratio_addons_mrr",
    "num_pacientes_total", "pacientes_ativos_12m",
    "potencial_economico", "ticket_medio",
    # Temporal
    "maturidade_meses",
]


def _get_available_features(df: pd.DataFrame) -> list:
    return [f for f in CLUSTER_FEATURES if f in df.columns
            and df[f].notna().sum() > len(df) * 0.5]


def prepare_cluster_matrix(df: pd.DataFrame) -> tuple:
    """
    Prepara matriz normalizada para clustering.
    Retorna (X_scaled, features_usadas, scaler, df_valid).
    """
    features = _get_available_features(df)
    df_valid = df[features].copy()

    # Imputa medianas (nunca médias em distribuições assimétricas de SaaS)
    for col in features:
        df_valid[col] = df_valid[col].fillna(df_valid[col].median())

    scaler   = StandardScaler()
    X_scaled = scaler.fit_transform(df_valid)

    print(f"✅ Matrix de clustering: {X_scaled.shape[0]} clientes × {X_scaled.shape[1]} features")
    return X_scaled, features, scaler, df_valid.index


def find_optimal_k(X: np.ndarray, k_range: range = range(2, 10)) -> int:
    """
    Determina k ideal por silhouette score.
    Usa cotovelo como tiebreak.
    """
    inertias    = []
    silhouettes = []

    for k in k_range:
        km = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = km.fit_predict(X)
        inertias.append(km.inertia_)
        silhouettes.append(silhouette_score(X, labels, sample_size=min(2000, len(X))))

    best_k = k_range[int(np.argmax(silhouettes))]

    # Exporta gráfico de seleção de k
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].plot(list(k_range), inertias, "bo-")
    axes[0].set_title("Método do Cotovelo", fontweight="bold")
    axes[0].set_xlabel("Número de Clusters (k)")
    axes[0].set_ylabel("Inércia")

    axes[1].plot(list(k_range), silhouettes, "go-")
    axes[1].axvline(x=best_k, color="red", linestyle="--", label=f"k={best_k}")
    axes[1].set_title("Silhouette Score por k", fontweight="bold")
    axes[1].set_xlabel("Número de Clusters (k)")
    axes[1].set_ylabel("Silhouette Score")
    axes[1].legend()

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    fig.suptitle("Seleção do Número Ideal de Clusters", fontsize=12, fontweight="bold")
    plt.tight_layout()
    fig.savefig(f"{OUTPUT_DIR}/cluster_k_selection.png", dpi=120, bbox_inches="tight")
    plt.close(fig)

    print(f"✅ k ideal: {best_k} (silhouette={max(silhouettes):.3f})")
    return best_k


def run_kmeans(X: np.ndarray, k: int) -> tuple:
    """Treina KMeans e retorna (model, labels)."""
    km = KMeans(n_clusters=k, random_state=42, n_init=15)
    labels = km.fit_predict(X)
    return km, labels


def label_clusters(df: pd.DataFrame, features: list) -> pd.DataFrame:
    """
    Gera perfil descritivo automático de cada cluster e atribui rótulo.
    Lógica baseada em posição relativa nas dimensões-chave.
    """
    profiles = []

    for seg in sorted(df["segmento"].unique()):
        sub = df[df["segmento"] == seg]
        n   = len(sub)

        # Dimensões-chave (usa fallback 0 se coluna ausente)
        def med(col):
            return sub[col].median() if col in sub.columns else 0

        mrr          = med("mrr_atual")
        adocao       = med("score_adocao_composto")
        pacientes    = med("num_pacientes_total")
        maturidade   = med("maturidade_meses")
        churn_rate   = sub["churn"].mean() if "churn" in sub.columns else 0
        ltv          = med("ltv_realizado")
        addons       = med("ratio_addons_mrr")

        # Geração de rótulo por heurística
        if mrr < 300 and adocao < 3:
            rotulo = "Solo Básico"
            descricao = "Clínica individual, uso superficial, risco de churn alto"
        elif mrr < 300 and adocao >= 3:
            rotulo = "Solo Engajado"
            descricao = "Clínica individual, usa bem o sistema, potencial para upsell"
        elif mrr >= 300 and mrr < 700 and pacientes < 1000:
            rotulo = "Pequena em Crescimento"
            descricao = "Multi-usuário pequeno, crescendo, boa retenção"
        elif mrr >= 300 and adocao >= 5 and addons > 0.1:
            rotulo = "Power User"
            descricao = "Alta adoção, usa addons, perfil mais próximo do ICP ideal"
        elif mrr >= 700 and pacientes >= 1000:
            rotulo = "Clínica Consolidada"
            descricao = "Alto MRR, grande base de pacientes, potencial para DS Pay e IA"
        elif maturidade > 24 and churn_rate < 0.1:
            rotulo = "Veterano Leal"
            descricao = "Cliente antigo com baixo churn, ainda com potencial de expansão"
        else:
            rotulo = f"Segmento {seg}"
            descricao = "Perfil misto — requer análise qualitativa"

        profiles.append({
            "segmento":        seg,
            "rotulo":          rotulo,
            "descricao":       descricao,
            "n_clientes":      n,
            "mrr_mediano":     round(mrr, 2),
            "ltv_mediano":     round(ltv, 2),
            "score_adocao":    round(adocao, 3),
            "pacientes_med":   round(pacientes, 0),
            "maturidade_med":  round(maturidade, 1),
            "churn_rate":      round(churn_rate * 100, 1),
        })

    perfil_df = pd.DataFrame(profiles)

    # Mapeia rótulo de volta ao df principal
    rotulo_map = dict(zip(perfil_df["segmento"], perfil_df["rotulo"]))
    df["segmento_rotulo"] = df["segmento"].map(rotulo_map)

    return df, perfil_df


def plot_pca_clusters(df: pd.DataFrame, X: np.ndarray) -> str:
    """Visualiza clusters em 2D via PCA."""
    pca    = PCA(n_components=2, random_state=42)
    coords = pca.fit_transform(X)

    fig, ax = plt.subplots(figsize=(10, 7))
    palette = sns.color_palette("tab10", n_colors=df["segmento"].nunique())

    for i, (seg, grp) in enumerate(df.groupby("segmento")):
        idx = grp.index
        # Precisa reindexar nos indices originais do df
        mask = df.index.isin(idx)
        ax.scatter(coords[mask, 0], coords[mask, 1],
                   label=grp["segmento_rotulo"].iloc[0],
                   color=palette[i], alpha=0.6, s=30)

    ax.set_title("Segmentação ICP — Projeção PCA", fontsize=13, fontweight="bold")
    ax.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.1f}%)")
    ax.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.1f}%)")
    ax.legend(bbox_to_anchor=(1.05, 1), loc="upper left", fontsize=9)
    plt.tight_layout()

    path = f"{OUTPUT_DIR}/cluster_pca.png"
    fig.savefig(path, dpi=120, bbox_inches="tight")
    plt.close(fig)
    return path


def plot_cluster_radar(perfil_df: pd.DataFrame) -> str:
    """Radar chart comparando dimensões dos clusters."""
    dims = ["mrr_mediano", "score_adocao", "pacientes_med",
            "maturidade_med", "churn_rate"]
    dims = [d for d in dims if d in perfil_df.columns]

    if len(dims) < 3:
        return ""

    norm_df = perfil_df.copy()
    for d in dims:
        mx = norm_df[d].max()
        norm_df[d] = norm_df[d] / mx if mx > 0 else 0

    angles = np.linspace(0, 2 * np.pi, len(dims), endpoint=False).tolist()
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(8, 8), subplot_kw={"polar": True})
    colors = plt.cm.tab10.colors

    for i, row in norm_df.iterrows():
        vals = [row[d] for d in dims] + [row[dims[0]]]
        ax.plot(angles, vals, color=colors[i % len(colors)], linewidth=2)
        ax.fill(angles, vals, color=colors[i % len(colors)], alpha=0.1)

    ax.set_thetagrids(np.degrees(angles[:-1]), dims)
    ax.set_title("Perfil dos Segmentos (Radar)", fontsize=12, fontweight="bold", y=1.08)
    ax.legend(norm_df["rotulo"].tolist(), loc="upper right",
              bbox_to_anchor=(1.3, 1.1), fontsize=9)
    plt.tight_layout()

    path = f"{OUTPUT_DIR}/cluster_radar.png"
    fig.savefig(path, dpi=120, bbox_inches="tight")
    plt.close(fig)
    return path


# ─────────────────────────────────────────────────────────────
# PIPELINE PRINCIPAL
# ─────────────────────────────────────────────────────────────
def run_segmentation(df: pd.DataFrame) -> tuple:
    """
    Executa pipeline completo de segmentação ICP.
    Retorna (df_com_segmentos, perfil_clusters, kmeans_model).
    """
    print("\n" + "="*60)
    print("  MÓDULO 03 — SEGMENTAÇÃO ICP (CLUSTERING)")
    print("="*60)

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(MODELS_DIR, exist_ok=True)

    X, features, scaler, valid_idx = prepare_cluster_matrix(df)

    k       = find_optimal_k(X)
    km, labels = run_kmeans(X, k)

    # Atribui segmentos apenas nas linhas válidas
    df_seg = df.copy()
    df_seg.loc[valid_idx, "segmento"] = labels

    # Clientes que não entraram no clustering (muitos nulos)
    df_seg["segmento"] = df_seg["segmento"].fillna(-1).astype(int)

    df_seg, perfil_df = label_clusters(df_seg, features)

    # Plots
    plot_pca_clusters(df_seg[df_seg["segmento"] >= 0].reset_index(drop=True),
                      X)
    plot_cluster_radar(perfil_df)

    # Salva modelo
    joblib.dump({"model": km, "scaler": scaler, "features": features},
                f"{MODELS_DIR}/kmeans_icp.pkl")

    print(f"\n✅ Segmentação concluída — {k} clusters identificados")
    print(perfil_df[["rotulo", "n_clientes", "mrr_mediano",
                      "score_adocao", "churn_rate"]].to_string(index=False))

    return df_seg, perfil_df, km


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")
    from src.preprocessing_01 import run_preprocessing
    from src.ltv_analysis_02 import run_ltv_analysis
    path = sys.argv[1] if len(sys.argv) > 1 else "data/clientes.csv"
    df, _ = run_preprocessing(path)
    df, _ = run_ltv_analysis(df)
    df_seg, perfil, model = run_segmentation(df)
