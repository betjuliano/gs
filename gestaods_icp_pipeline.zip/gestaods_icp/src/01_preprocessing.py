"""
Módulo 01 — Pré-processamento e Feature Engineering
GestãoDS ICP Analysis Pipeline

Responsabilidades:
  - Carregar CSV e normalizar nomes de colunas
  - Tratar nulos com estratégia diferenciada por tipo
  - Encodar variáveis booleanas, semáforos e categóricas
  - Calcular LTV realizado e projetado
  - Criar features derivadas para modelagem
  - Detectar e tratar possível leakage do NPS
  - Validar e reconciliar Faturamento_Mensal_Estimado
"""

import re
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
import warnings
warnings.filterwarnings("ignore")

# ─────────────────────────────────────────────────────────────
# MAPA DE COLUNAS
# Chave  = nome interno usado em todo o pipeline
# Valor  = nome original esperado no CSV (case-insensitive)
# Ajuste os VALORES se o seu CSV tiver nomes diferentes.
# ─────────────────────────────────────────────────────────────
COLUMN_MAP = {
    "id_cliente":              "ID_Cliente",
    "nome_clinica":            "Nome_Clinica",
    "cnpj":                    "CNPJ",
    "cidade":                  "Cidade",
    "uf":                      "UF",
    "num_medicos":             "Numero_Medicos_Ativos",
    "num_secretarias":         "Numero_Secretarias_Admin_Ativas",
    "especialidades":          "Especialidades",
    "especialidade_principal": "Especialidade_Principal",
    "canal_origem":            "Canal_Aquisicao_Origem",
    "canal_suborigem":         "Canal_Aquisicao_SubOrigem",
    "data_inicio":             "Data_Inicio_Contrato",
    "data_cancelamento":       "Data_Cancelamento",
    "status":                  "Status",
    "motivo_churn":            "Motivo_Churn",
    "nps":                     "NPS_SuperAdmin",
    "mrr_atual":               "MRR_Geral_Atual",
    "mrr_medio_historico":     "MRR_Medio_Historico",
    "receita_total":           "Receita_Total_Historica",
    "plano_atual":             "Plano_Atual",
    "mrr_plano":               "MRR_Plano_Atual",
    "fez_upgrade":             "Fez_Upgrade",
    "fez_downgrade":           "Fez_Downgrade",
    "valor_addons":            "Valor_Addons",
    "mau":                     "MAU_Ultimos_3_Meses",
    "semaforo_essencial":      "Semaforo_Essencial",
    "score_operacional":       "Score_Operacional",
    "usa_financeiro":          "Usa_Financeiro",
    "semaforo_financeiro":     "Semaforo_Modulo_Financeiro",
    "usa_conciliacao":         "Usa_Conciliacao_Bancaria",
    "score_financeiro":        "Score_Financeiro",
    "fluxo_whatsapp":          "Fluxo_Pre_Pos_Whatsapp",
    "score_jornada":           "Score_Jornada",
    "usa_ia":                  "Usa_IA",
    "usa_chatgds":             "Usa_ChatGDS",
    "num_pacientes_total":     "Numero_Pacientes_Total",
    "pacientes_novos_6m":      "Pacientes_Novos_6_Meses",
    "pacientes_novos_12m":     "Pacientes_Novos_12_Meses",
    "pacientes_ativos_6m":     "Pacientes_Ativos_6_Meses",
    "pacientes_ativos_12m":    "Pacientes_Ativos_12_Meses",
    "ticket_medio":            "Ticket_Medio_Clinica",
    "faturamento_mensal":      "Faturamento_Mensal_Estimado",
}

SEMAFORO_MAP = {
    "baixo": 0, "low": 0, "ruim": 0, "fraco": 0, "pouco": 0,
    "médio": 1, "medio": 1, "medium": 1, "razoável": 1,
    "razoavel": 1, "regular": 1,
    "alto": 2, "high": 2, "bom": 2, "ótimo": 2, "otimo": 2, "ativo": 2,
}

BOOL_COLS     = ["usa_financeiro", "usa_conciliacao", "fluxo_whatsapp",
                 "usa_ia", "usa_chatgds", "fez_upgrade", "fez_downgrade"]
SEMAFORO_COLS = ["semaforo_essencial", "semaforo_financeiro"]
SCORE_COLS    = ["score_operacional", "score_financeiro", "score_jornada"]
NUMERIC_COLS  = ["num_medicos", "num_secretarias", "nps", "mrr_atual",
                 "mrr_medio_historico", "receita_total", "mrr_plano",
                 "valor_addons", "mau", "num_pacientes_total",
                 "pacientes_novos_6m", "pacientes_novos_12m",
                 "pacientes_ativos_6m", "pacientes_ativos_12m",
                 "ticket_medio", "faturamento_mensal"]


# ─────────────────────────────────────────────────────────────
# 1. CARREGAMENTO
# ─────────────────────────────────────────────────────────────
def _normalize_col_name(name: str) -> str:
    return re.sub(r"[^a-z0-9_]", "", name.lower().strip().replace(" ", "_"))


def load_and_normalize(filepath: str) -> pd.DataFrame:
    df = pd.read_csv(filepath, encoding="utf-8", sep=None, engine="python")
    df.columns = [_normalize_col_name(c) for c in df.columns]

    reverse = {_normalize_col_name(orig): key for key, orig in COLUMN_MAP.items()}
    df.rename(columns=reverse, inplace=True)

    missing = [c for c in COLUMN_MAP if c not in df.columns]
    if missing:
        print(f"⚠️  Colunas não encontradas (criadas como NaN): {missing}")
        for col in missing:
            df[col] = np.nan

    print(f"✅ Base carregada: {len(df):,} linhas | {len(df.columns)} colunas")
    return df


# ─────────────────────────────────────────────────────────────
# 2. DATAS E TEMPO DE VIDA
# ─────────────────────────────────────────────────────────────
def parse_dates(df: pd.DataFrame) -> pd.DataFrame:
    today = pd.Timestamp.today().normalize()
    for col in ["data_inicio", "data_cancelamento"]:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce", dayfirst=True)

    if "data_inicio" in df.columns:
        data_fim = df["data_cancelamento"].where(df["data_cancelamento"].notna(), today)
        df["dias_ativo"]       = (data_fim - df["data_inicio"]).dt.days.clip(lower=0)
        df["anos_ativos"]      = (df["dias_ativo"] / 365.25).round(2)
        df["cohort_trimestre"] = df["data_inicio"].dt.to_period("Q").astype(str)
    else:
        df["dias_ativo"]       = np.nan
        df["anos_ativos"]      = np.nan
        df["cohort_trimestre"] = "Desconhecido"
    return df


# ─────────────────────────────────────────────────────────────
# 3. STATUS / CHURN
# ─────────────────────────────────────────────────────────────
def encode_status(df: pd.DataFrame) -> pd.DataFrame:
    cancelados = ["cancelado", "cancelled", "canceled", "inativo", "churn"]
    if "status" in df.columns:
        df["churn"] = (
            df["status"].astype(str).str.lower().str.strip()
            .isin(cancelados).astype(int)
        )
    else:
        df["churn"] = 0

    for col in ["canal_origem", "canal_suborigem"]:
        if col in df.columns:
            df[col] = df[col].fillna("nao_rastreado").str.strip()
    return df


# ─────────────────────────────────────────────────────────────
# 4. BOOLEANOS, SEMÁFOROS E SCORES
# ─────────────────────────────────────────────────────────────
def _to_bool(val) -> int:
    if pd.isna(val):
        return 0
    return 1 if str(val).lower().strip() in ("sim", "yes", "true", "1", "s") else 0


def encode_booleans(df: pd.DataFrame) -> pd.DataFrame:
    for col in BOOL_COLS:
        if col in df.columns:
            df[col] = df[col].apply(_to_bool)
    return df


def encode_semaforos(df: pd.DataFrame) -> pd.DataFrame:
    for col in SEMAFORO_COLS:
        if col not in df.columns:
            continue
        if pd.api.types.is_numeric_dtype(df[col]):
            df[col] = df[col].fillna(0).clip(0, 2).astype(int)
        else:
            df[col] = (
                df[col].astype(str).str.lower().str.strip()
                .map(SEMAFORO_MAP).fillna(0).astype(int)
            )
    return df


def encode_scores_and_numerics(df: pd.DataFrame) -> pd.DataFrame:
    for col in SCORE_COLS + NUMERIC_COLS:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


# ─────────────────────────────────────────────────────────────
# 5. FATURAMENTO — VALIDAÇÃO E RECONCILIAÇÃO
# ─────────────────────────────────────────────────────────────
def reconcile_faturamento(df: pd.DataFrame) -> pd.DataFrame:
    """
    Cria faturamento_reconciliado.
    Se divergência entre original e alternativo > 40%,
    usa o alternativo e sinaliza o cliente.
    """
    z   = pd.Series(0.0, index=df.index)
    tk  = df.get("ticket_medio",        z).fillna(0)
    pac = df.get("pacientes_ativos_12m", z).fillna(0)
    fat = df.get("faturamento_mensal",   pd.Series(np.nan, index=df.index))

    fat_alt = (tk * pac / 12).round(2)
    df["faturamento_alternativo"] = fat_alt

    with np.errstate(divide="ignore", invalid="ignore"):
        div = np.abs(fat.fillna(0) - fat_alt) / fat_alt.replace(0, np.nan)

    df["flag_faturamento_divergente"] = (div > 0.4).astype(int)
    df["faturamento_reconciliado"] = np.where(
        df["flag_faturamento_divergente"] == 1,
        fat_alt,
        fat.fillna(fat_alt),
    )

    n = df["flag_faturamento_divergente"].sum()
    if n > 0:
        print(f"⚠️  {n} clientes com faturamento divergente >40% — usando estimativa alternativa.")
    return df


# ─────────────────────────────────────────────────────────────
# 6. AUDITORIA DE LEAKAGE DO NPS
# ─────────────────────────────────────────────────────────────
def audit_nps_leakage(df: pd.DataFrame) -> dict:
    """
    Testa se NPS é safe para modelo preditivo de churn.
    Correlação < -0.5 com churn indica possível leakage.
    """
    result = {"usar_nps_no_modelo": True, "correlacao": None, "aviso": ""}

    if "nps" not in df.columns or "churn" not in df.columns:
        result["usar_nps_no_modelo"] = False
        result["aviso"] = "NPS ou churn ausente."
        return result

    valid = df[["nps", "churn"]].dropna()
    if len(valid) < 50:
        result["usar_nps_no_modelo"] = False
        result["aviso"] = "Menos de 50 registros com NPS."
        return result

    corr = valid["nps"].corr(valid["churn"])
    result["correlacao"] = round(corr, 4)

    if corr < -0.5:
        result["usar_nps_no_modelo"] = False
        result["aviso"] = (
            f"NPS com correlação forte com churn ({corr:.2f}) — "
            "possível coleta no cancelamento. Excluído do modelo preditivo."
        )
    else:
        result["aviso"] = (
            f"NPS com correlação moderada/baixa ({corr:.2f}). "
            "Usado como feature secundária."
        )

    print(f"🔍 Auditoria NPS: {result['aviso']}")
    return result


# ─────────────────────────────────────────────────────────────
# 7. LTV
# ─────────────────────────────────────────────────────────────
def calculate_ltv(df: pd.DataFrame) -> pd.DataFrame:
    z       = pd.Series(0.0, index=df.index)
    dias    = df.get("dias_ativo",           z).fillna(0)
    mrr_med = df.get("mrr_medio_historico",  z).fillna(0)
    mrr_atu = df.get("mrr_atual",            z).fillna(0)
    receita = df.get("receita_total",        pd.Series(np.nan, index=df.index))

    ltv_calc          = mrr_med * (dias / 30)
    df["ltv_realizado"] = pd.to_numeric(receita, errors="coerce").fillna(ltv_calc).round(2)

    churn_global  = df["churn"].mean() if "churn" in df.columns else 0.03
    churn_mensal  = max(churn_global / 12, 0.005)
    df["ltv_projetado"] = (mrr_atu / churn_mensal).round(2)
    return df


# ─────────────────────────────────────────────────────────────
# 8. FEATURE ENGINEERING
# ─────────────────────────────────────────────────────────────
def feature_engineering(df: pd.DataFrame, nps_audit: dict) -> pd.DataFrame:
    z = pd.Series(0.0, index=df.index)

    # Porte
    df["total_usuarios"] = (
        df.get("num_medicos",    z).fillna(0)
        + df.get("num_secretarias", z).fillna(0)
    )
    df["porte_clinica"] = pd.cut(
        df["total_usuarios"],
        bins=[-1, 1, 3, 7, 15, 9999],
        labels=["Solo", "Micro", "Pequena", "Media", "Grande"],
    )

    # Crescimento de pacientes
    p6  = df.get("pacientes_novos_6m",  z).fillna(0)
    p12 = df.get("pacientes_novos_12m", z).fillna(0)
    ptot = df.get("num_pacientes_total", z).fillna(0)
    df["crescimento_pacientes_6_12"] = np.where(p12 > 0, (p12 - p6) / p12, 0)
    df["taxa_novos_pacientes_6m"]    = np.where(ptot > 0, p6 / ptot, 0)

    # Ratio addons / MRR
    mrr = df.get("mrr_atual", z).fillna(0)
    adn = df.get("valor_addons", z).fillna(0)
    df["ratio_addons_mrr"] = np.where(mrr > 0, adn / mrr, 0)

    # Score composto de adoção (0–10 aprox.)
    def norm(s, mx=100):
        return (pd.to_numeric(s, errors="coerce").fillna(0) / mx).clip(0, 1)

    df["score_adocao_composto"] = (
        norm(df.get("score_operacional", z)) * 2.0
        + norm(df.get("score_financeiro",  z)) * 1.5
        + norm(df.get("score_jornada",     z)) * 1.5
        + (df.get("semaforo_essencial",  z).fillna(0) / 2) * 1.0
        + (df.get("semaforo_financeiro", z).fillna(0) / 2) * 1.0
        + df.get("usa_financeiro",  z).fillna(0) * 0.5
        + df.get("fluxo_whatsapp",  z).fillna(0) * 0.5
        + df.get("usa_ia",          z).fillna(0) * 0.5
        + df.get("usa_chatgds",     z).fillna(0) * 0.5
        + df.get("usa_conciliacao", z).fillna(0) * 1.0
    ).round(3)

    # Potencial econômico (log-escala)
    fat = df.get("faturamento_reconciliado",
                 df.get("faturamento_mensal", z)).fillna(0)
    df["potencial_economico"] = np.log1p(fat)

    # NPS tratado
    df["nps_tratado"] = df.get("nps", pd.Series(np.nan, index=df.index))
    if not nps_audit.get("usar_nps_no_modelo", True):
        df["nps_tratado"] = np.nan

    # Maturidade
    df["maturidade_meses"] = (df.get("dias_ativo", z).fillna(0) / 30).round(1)
    df["cliente_maduro"]   = (df["maturidade_meses"] >= 3).astype(int)

    # Flag canal rastreável
    canal = df.get("canal_origem", pd.Series("nao_rastreado", index=df.index))
    df["canal_rastreavel"] = (canal.str.lower() != "nao_rastreado").astype(int)

    return df


# ─────────────────────────────────────────────────────────────
# 9. ENCODING CATEGÓRICO FINAL
# ─────────────────────────────────────────────────────────────
def encode_categoricals(df: pd.DataFrame) -> pd.DataFrame:
    # One-hot: plano e canal (baixa cardinalidade)
    for col, prefix in [("plano_atual", "plano"), ("canal_origem", "canal")]:
        if col in df.columns:
            dummies = pd.get_dummies(df[col], prefix=prefix, dummy_na=False)
            df = pd.concat([df, dummies.astype(int)], axis=1)

    # Label encoding: especialidade e UF (alta cardinalidade)
    for col, new_col in [("especialidade_principal", "especialidade_encoded"),
                         ("uf", "uf_encoded")]:
        if col in df.columns:
            le = LabelEncoder()
            df[new_col] = le.fit_transform(df[col].fillna("Desconhecido").astype(str))

    # Porte ordinal
    porte_map = {"Solo": 0, "Micro": 1, "Pequena": 2, "Media": 3, "Grande": 4}
    if "porte_clinica" in df.columns:
        df["porte_encoded"] = df["porte_clinica"].map(porte_map).fillna(0).astype(int)

    return df


# ─────────────────────────────────────────────────────────────
# 10. PIPELINE PRINCIPAL
# ─────────────────────────────────────────────────────────────
def run_preprocessing(filepath: str) -> tuple:
    """
    Executa o pipeline completo de pré-processamento.
    Retorna (df_processado, metadata).
    """
    print("\n" + "="*60)
    print("  MÓDULO 01 — PRÉ-PROCESSAMENTO")
    print("="*60)

    df = load_and_normalize(filepath)
    df = parse_dates(df)
    df = encode_status(df)
    df = encode_booleans(df)
    df = encode_semaforos(df)
    df = encode_scores_and_numerics(df)
    df = reconcile_faturamento(df)
    nps_audit = audit_nps_leakage(df)
    df = calculate_ltv(df)
    df = feature_engineering(df, nps_audit)
    df = encode_categoricals(df)

    n_cancel  = int(df["churn"].sum())
    n_total   = len(df)
    pct_churn = round(n_cancel / n_total * 100, 2)

    metadata = {
        "n_total":       n_total,
        "n_ativos":      n_total - n_cancel,
        "n_cancelados":  n_cancel,
        "pct_churn":     pct_churn,
        "nps_audit":     nps_audit,
        "n_sem_canal":   int((df.get("canal_rastreavel",
                               pd.Series(0, index=df.index)) == 0).sum()),
        "n_divergentes": int(df.get("flag_faturamento_divergente",
                                    pd.Series(0, index=df.index)).sum()),
        "precisa_smote": pct_churn < 20 or pct_churn > 80,
    }

    print(f"\n📊 Resumo:")
    print(f"   Total         : {n_total:,}")
    print(f"   Ativos        : {metadata['n_ativos']:,}")
    print(f"   Cancelados    : {n_cancel:,} ({pct_churn}%)")
    print(f"   Sem canal     : {metadata['n_sem_canal']:,}")
    print(f"   SMOTE needed  : {metadata['precisa_smote']}")

    return df, metadata


if __name__ == "__main__":
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else "data/clientes.csv"
    df, meta = run_preprocessing(path)
    print(df.shape)
