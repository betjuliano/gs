"""
Módulo 05 — Modelos de Propensão para Cross-sell / Upsell
GestãoDS ICP Analysis Pipeline

Produtos:
  1. DS Pay      — maquininha + conciliação bancária
  2. Agentes IA  — 4 agentes de IA (transcrição + automação)
  3. ChatGDS     — plataforma de mensageria

Para cada produto:
  - Usa clientes que já adotaram como label positivo (treino)
  - Prediz probabilidade de adoção para quem ainda não tem
  - Gera score 0–100 e ranking priorizado
"""

import os
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

OUTPUT_DIR = "outputs"
MODELS_DIR = "outputs/models"

# ─────────────────────────────────────────────────────────────
# CONFIGURAÇÃO DE CADA PRODUTO
# ─────────────────────────────────────────────────────────────
PRODUCTS = {
    "ds_pay": {
        "label_col":   "usa_conciliacao",   # quem já usa = positivo
        "score_col":   "score_propensao_ds_pay",
        "nome":        "DS Pay",
        "descricao":   "Maquininha + Conciliação Bancária",
        "features": [
            "usa_financeiro", "semaforo_financeiro", "score_financeiro",
            "mrr_atual", "faturamento_reconciliado", "potencial_economico",
            "num_pacientes_total", "pacientes_ativos_12m",
            "ticket_medio", "total_usuarios", "porte_encoded",
            "fez_upgrade", "score_adocao_composto", "maturidade_meses",
        ],
    },
    "agentes_ia": {
        "label_col":   "usa_ia",
        "score_col":   "score_propensao_ia",
        "nome":        "Agentes de IA",
        "descricao":   "Transcrição IA + Automação de Prontuário",
        "features": [
            "score_operacional", "score_adocao_composto", "mau",
            "pacientes_novos_6m", "pacientes_novos_12m",
            "crescimento_pacientes_6_12", "taxa_novos_pacientes_6m",
            "total_usuarios", "porte_encoded", "mrr_atual",
            "faturamento_reconciliado", "potencial_economico",
            "semaforo_essencial", "usa_financeiro", "maturidade_meses",
        ],
    },
    "chatgds": {
        "label_col":   "usa_chatgds",
        "score_col":   "score_propensao_chatgds",
        "nome":        "ChatGDS",
        "descricao":   "Plataforma de Mensageria",
        "features": [
            "fluxo_whatsapp", "score_jornada", "score_adocao_composto",
            "mau", "num_pacientes_total", "pacientes_ativos_6m",
            "total_usuarios", "porte_encoded", "mrr_atual",
            "semaforo_essencial", "usa_financeiro",
            "maturidade_meses", "fez_upgrade",
        ],
    },
}


def prepare_propensity_data(df: pd.DataFrame, product_cfg: dict) -> tuple:
    """
    Prepara X, y para um modelo de propensão.
    Inclui apenas clientes ativos (churn=0) que já têm o produto (y=1)
    ou que ainda não têm (y=0) — mas exclui cancelados do treino.
    """
    label_col = product_cfg["label_col"]
    features  = [f for f in product_cfg["features"]
                 if f in df.columns and df[f].notna().mean() > 0.4]

    if label_col not in df.columns:
        print(f"⚠️  Coluna '{label_col}' não encontrada. Pulando produto.")
        return None, None, None

    # Apenas clientes ativos
    df_active = df[df.get("churn", pd.Series(0, index=df.index)) == 0].copy()

    if df_active[label_col].sum() < 20:
        print(f"⚠️  Menos de 20 clientes com '{label_col}=1'. Modelo de propensão pode ser instável.")

    X = df_active[features].copy()
    y = df_active[label_col].fillna(0).astype(int).values

    for col in X.columns:
        X[col] = X[col].fillna(X[col].median())

    pct_pos = y.mean() * 100
    print(f"   {product_cfg['nome']}: {len(X):,} clientes | {y.sum()} adotantes ({pct_pos:.1f}%)")

    return X, y, features


def train_propensity_model(X: pd.DataFrame, y: np.ndarray,
                            product_name: str) -> tuple:
    """Treina XGBoost de propensão com cross-validation."""
    if X is None or len(X) == 0:
        return None, None

    scale_weight = (1 - y.mean()) / max(y.mean(), 0.01)

    model = XGBClassifier(
        n_estimators=200,
        max_depth=4,
        learning_rate=0.08,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=scale_weight,
        random_state=42,
        eval_metric="auc",
        verbosity=0,
        use_label_encoder=False,
    )

    n_splits = min(5, max(2, int(y.sum() / 5)))
    cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)

    try:
        scores = cross_val_score(model, X.values, y, cv=cv, scoring="roc_auc")
        model.fit(X.values, y)
        print(f"   AUC-ROC {product_name}: {scores.mean():.3f} ± {scores.std():.3f}")
        return model, scores
    except Exception as e:
        print(f"⚠️  Erro no modelo {product_name}: {e}")
        return None, None


def score_propensity(df: pd.DataFrame, model, features: list,
                     score_col: str, label_col: str) -> pd.DataFrame:
    """
    Aplica modelo a clientes que ainda NÃO têm o produto.
    Adiciona score de 0-100 e ranking.
    """
    if model is None:
        return df

    ativos    = df[df.get("churn", pd.Series(0, index=df.index)) == 0]
    sem_prod  = ativos[ativos.get(label_col, pd.Series(0, index=ativos.index)) == 0]

    if len(sem_prod) == 0:
        return df

    avail_feats = [f for f in features if f in sem_prod.columns]
    X_score = sem_prod[avail_feats].copy()
    for col in X_score.columns:
        X_score[col] = X_score[col].fillna(X_score[col].median())

    # Alinha features com o modelo
    for f in features:
        if f not in X_score.columns:
            X_score[f] = 0
    X_score = X_score[features]

    probs = model.predict_proba(X_score.values)[:, 1]
    df.loc[sem_prod.index, score_col] = (probs * 100).round(1)

    # Ranking (só entre quem não tem o produto)
    rank_col = score_col.replace("score_propensao", "rank_propensao")
    df.loc[sem_prod.index, rank_col] = (
        df.loc[sem_prod.index, score_col]
        .rank(ascending=False, method="min")
        .astype("Int64")
    )

    return df


def generate_priority_lists(df: pd.DataFrame, n_top: int = 50) -> dict:
    """
    Gera lista de priorização comercial por produto:
    top-N clientes ativos com maior propensão e sem o produto ainda.
    """
    priority = {}
    cols_base = ["id_cliente", "nome_clinica", "especialidade_principal",
                 "uf", "mrr_atual", "total_usuarios", "score_adocao_composto",
                 "maturidade_meses"]
    cols_base = [c for c in cols_base if c in df.columns]

    for key, cfg in PRODUCTS.items():
        score_col = cfg["score_col"]
        label_col = cfg["label_col"]

        if score_col not in df.columns:
            continue

        target = df[
            (df.get("churn", pd.Series(0, index=df.index)) == 0)
            & (df.get(label_col, pd.Series(0, index=df.index)) == 0)
            & df[score_col].notna()
        ].copy()

        top = (target
               .sort_values(score_col, ascending=False)
               .head(n_top)[cols_base + [score_col]]
               .reset_index(drop=True))
        top.index += 1
        priority[cfg["nome"]] = top

    return priority


# ─────────────────────────────────────────────────────────────
# VISUALIZAÇÕES
# ─────────────────────────────────────────────────────────────
def plot_propensity_overview(df: pd.DataFrame) -> str:
    """Box plot de scores de propensão por produto."""
    score_cols = {
        "DS Pay":      "score_propensao_ds_pay",
        "Agentes IA":  "score_propensao_ia",
        "ChatGDS":     "score_propensao_chatgds",
    }

    data_plot = {k: df[v].dropna() for k, v in score_cols.items() if v in df.columns}
    if not data_plot:
        return ""

    fig, axes = plt.subplots(1, len(data_plot), figsize=(5 * len(data_plot), 5))
    if len(data_plot) == 1:
        axes = [axes]

    colors = ["#7c3aed", "#0891b2", "#16a34a"]
    for ax, (nome, vals), color in zip(axes, data_plot.items(), colors):
        ax.hist(vals, bins=30, color=color, alpha=0.75, edgecolor="white")
        ax.axvline(vals.median(), color="red", linestyle="--",
                   label=f"Mediana: {vals.median():.0f}")
        ax.set_title(f"Propensão — {nome}", fontweight="bold")
        ax.set_xlabel("Score de Propensão (0–100)")
        ax.set_ylabel("Clientes")
        ax.legend()

    plt.suptitle("Distribuição de Scores de Propensão por Produto",
                 fontsize=12, fontweight="bold")
    plt.tight_layout()

    path = f"{OUTPUT_DIR}/propensity_overview.png"
    fig.savefig(path, dpi=120, bbox_inches="tight")
    plt.close(fig)
    return path


def plot_propensity_by_segment(df: pd.DataFrame) -> str:
    """Score médio de propensão por segmento de cluster."""
    if "segmento_rotulo" not in df.columns:
        return ""

    score_cols = {
        "DS Pay":     "score_propensao_ds_pay",
        "Agentes IA": "score_propensao_ia",
        "ChatGDS":    "score_propensao_chatgds",
    }
    avail = {k: v for k, v in score_cols.items() if v in df.columns}
    if not avail:
        return ""

    agg = df.groupby("segmento_rotulo")[[v for v in avail.values()]].mean().round(1)
    agg.columns = list(avail.keys())

    fig, ax = plt.subplots(figsize=(11, 5))
    x      = np.arange(len(agg))
    width  = 0.25
    colors = ["#7c3aed", "#0891b2", "#16a34a"]

    for i, (col, color) in enumerate(zip(avail.keys(), colors)):
        ax.bar(x + i * width, agg[col], width, label=col, color=color, alpha=0.8)

    ax.set_xticks(x + width)
    ax.set_xticklabels(agg.index, rotation=25, ha="right")
    ax.set_ylabel("Score Médio de Propensão")
    ax.set_title("Propensão por Produto × Segmento ICP", fontweight="bold")
    ax.legend()
    ax.set_ylim(0, 100)
    plt.tight_layout()

    path = f"{OUTPUT_DIR}/propensity_by_segment.png"
    fig.savefig(path, dpi=120, bbox_inches="tight")
    plt.close(fig)
    return path


# ─────────────────────────────────────────────────────────────
# PIPELINE PRINCIPAL
# ─────────────────────────────────────────────────────────────
def run_propensity_models(df: pd.DataFrame) -> tuple:
    """
    Treina e aplica os 3 modelos de propensão.
    Retorna (df_com_scores, priority_lists, models_dict).
    """
    print("\n" + "="*60)
    print("  MÓDULO 05 — MODELOS DE PROPENSÃO")
    print("="*60)

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(MODELS_DIR, exist_ok=True)

    models_dict = {}

    for key, cfg in PRODUCTS.items():
        print(f"\n📦 Produto: {cfg['nome']} — {cfg['descricao']}")

        X, y, features = prepare_propensity_data(df, cfg)

        if X is None:
            continue

        model, scores = train_propensity_model(X, y, cfg["nome"])

        if model is None:
            continue

        df = score_propensity(df, model, features, cfg["score_col"], cfg["label_col"])

        models_dict[key] = {
            "model":    model,
            "features": features,
            "auc_mean": scores.mean() if scores is not None else None,
        }

        joblib.dump(models_dict[key], f"{MODELS_DIR}/propensity_{key}.pkl")

    # Listas de prioridade
    priority_lists = generate_priority_lists(df)

    # Plots
    plot_propensity_overview(df)
    plot_propensity_by_segment(df)

    print(f"\n✅ Módulo 05 concluído — {len(models_dict)} modelos treinados")
    for nome, top in priority_lists.items():
        print(f"   {nome}: {len(top)} clientes priorizados")

    return df, priority_lists, models_dict


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")
    from src.preprocessing_01 import run_preprocessing
    from src.ltv_analysis_02 import run_ltv_analysis
    from src.segmentation_03 import run_segmentation
    from src.churn_model_04 import run_churn_model

    path = sys.argv[1] if len(sys.argv) > 1 else "data/clientes.csv"
    df, meta = run_preprocessing(path)
    df, _    = run_ltv_analysis(df)
    df, _, _ = run_segmentation(df)
    df, _, _, _, _ = run_churn_model(df, meta["nps_audit"])
    df, priority, models = run_propensity_models(df)
    print(priority.get("DS Pay", "").head())
