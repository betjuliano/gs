"""
Módulo 06 — Geração de Relatório Excel
GestãoDS ICP Analysis Pipeline

Gera icp_report.xlsx com abas:
  1. Resumo Executivo
  2. Top 25% ICP
  3. Clientes Scored (base completa)
  4. Segmentos ICP
  5. Risco de Churn
  6. Propensão DS Pay
  7. Propensão Agentes IA
  8. Propensão ChatGDS
  9. Análise por Canal
  10. Coorte de Retenção
  11. Tiers de Precificação
"""

import os
import pandas as pd
import numpy as np
from openpyxl import load_workbook
from openpyxl.styles import (PatternFill, Font, Alignment, Border, Side,
                               numbers)
from openpyxl.utils import get_column_letter
from openpyxl.utils.dataframe import dataframe_to_rows
import warnings
warnings.filterwarnings("ignore")

OUTPUT_DIR  = "outputs"
REPORT_PATH = f"{OUTPUT_DIR}/icp_report.xlsx"

# Paleta de cores GestãoDS
COLORS = {
    "header_azul":    "1E3A5F",
    "header_verde":   "15803D",
    "header_roxo":    "6D28D9",
    "header_laranja": "C2410C",
    "header_cinza":   "374151",
    "row_alt":        "F0F9FF",
    "verde_claro":    "DCFCE7",
    "vermelho_claro": "FEE2E2",
    "amarelo_claro":  "FEF9C3",
    "branco":         "FFFFFF",
}


def _header_fill(color_hex: str) -> PatternFill:
    return PatternFill("solid", fgColor=color_hex)


def _header_font(bold=True) -> Font:
    return Font(color="FFFFFF", bold=bold, size=10)


def _border_thin():
    side = Side(style="thin", color="D1D5DB")
    return Border(left=side, right=side, top=side, bottom=side)


def _auto_width(ws, min_w=8, max_w=40):
    for col in ws.columns:
        max_len = max_w
        col_letter = get_column_letter(col[0].column)
        lengths = [len(str(cell.value or "")) for cell in col]
        if lengths:
            calc = min(max(min_w, max(lengths) + 2), max_w)
            ws.column_dimensions[col_letter].width = calc


def _write_df_to_sheet(ws, df: pd.DataFrame, header_color: str,
                        start_row: int = 1):
    """Escreve DataFrame em uma sheet com formatação."""
    fill    = _header_fill(header_color)
    h_font  = _header_font()
    border  = _border_thin()
    alt_fill = PatternFill("solid", fgColor=COLORS["row_alt"])

    # Header
    for col_idx, col_name in enumerate(df.columns, 1):
        cell = ws.cell(row=start_row, column=col_idx, value=str(col_name))
        cell.fill   = fill
        cell.font   = h_font
        cell.border = border
        cell.alignment = Alignment(horizontal="center", vertical="center",
                                    wrap_text=True)

    # Dados
    for row_idx, row in enumerate(df.itertuples(index=False), start_row + 1):
        for col_idx, val in enumerate(row, 1):
            # Trata tipos numpy
            if isinstance(val, (np.integer,)):
                val = int(val)
            elif isinstance(val, (np.floating,)):
                val = float(val) if not np.isnan(val) else ""
            elif pd.isna(val) if not isinstance(val, str) else False:
                val = ""

            cell = ws.cell(row=row_idx, column=col_idx, value=val)
            cell.border = border
            cell.alignment = Alignment(vertical="center")

            # Zebra
            if row_idx % 2 == 0:
                cell.fill = alt_fill

    ws.row_dimensions[start_row].height = 30
    _auto_width(ws)


def _add_kpi_block(ws, kpis: dict, start_row: int = 1):
    """Escreve bloco de KPIs em 2 colunas: Label | Valor."""
    bold  = Font(bold=True, size=11)
    label_fill = PatternFill("solid", fgColor="EFF6FF")

    for i, (label, value) in enumerate(kpis.items(), start_row):
        c1 = ws.cell(row=i, column=1, value=label)
        c2 = ws.cell(row=i, column=2, value=value)
        c1.font = bold
        c1.fill = label_fill
        c1.border = _border_thin()
        c2.border = _border_thin()
        c2.alignment = Alignment(horizontal="center")

    ws.column_dimensions["A"].width = 35
    ws.column_dimensions["B"].width = 20


# ─────────────────────────────────────────────────────────────
# ABAS ESPECÍFICAS
# ─────────────────────────────────────────────────────────────
def sheet_resumo(wb, df: pd.DataFrame, results: dict, meta: dict):
    ws = wb.create_sheet("Resumo Executivo")
    ws.sheet_view.showGridLines = False

    # Título
    ws.merge_cells("A1:E1")
    title = ws["A1"]
    title.value     = "GestãoDS — Análise ICP e Precificação"
    title.font      = Font(bold=True, size=14, color=COLORS["header_azul"])
    title.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 35

    kpis = {
        "Total de Clientes na Base":          meta.get("n_total", "—"),
        "Clientes Ativos":                    meta.get("n_ativos", "—"),
        "Clientes Cancelados":                meta.get("n_cancelados", "—"),
        "Taxa de Churn Histórico (%)":        f"{meta.get('pct_churn', '—')}%",
        "Clientes Sem Canal Rastreável":       meta.get("n_sem_canal", "—"),
        "Clientes com Faturamento Reconciliado": meta.get("n_divergentes", "—"),
        "NPS usado no modelo preditivo":      "Sim" if meta.get("nps_audit", {}).get("usar_nps_no_modelo") else "Não",
    }

    # LTV stats se disponível
    if "ltv_realizado" in df.columns:
        kpis["LTV Mediano (R$)"]     = f"R$ {df['ltv_realizado'].median():,.0f}"
        kpis["LTV Top 25% — Mediano (R$)"] = (
            f"R$ {df[df.get('top25_ltv', pd.Series(0))==1]['ltv_realizado'].median():,.0f}"
            if "top25_ltv" in df.columns else "—"
        )
        kpis["MRR Médio da Base (R$)"] = (
            f"R$ {df['mrr_atual'].median():,.0f}" if "mrr_atual" in df.columns else "—"
        )

    _add_kpi_block(ws, kpis, start_row=3)


def sheet_top_icp(wb, df: pd.DataFrame, perfil: dict):
    ws = wb.create_sheet("Top 25% ICP")
    ws.sheet_view.showGridLines = False

    if "top25_ltv" not in df.columns:
        return

    cols = [c for c in [
        "id_cliente", "nome_clinica", "especialidade_principal", "uf",
        "porte_clinica", "total_usuarios", "mrr_atual", "ltv_realizado",
        "score_adocao_composto", "dias_ativo", "risco_churn", "segmento_rotulo",
        "score_propensao_ds_pay", "score_propensao_ia", "score_propensao_chatgds",
    ] if c in df.columns]

    top = (df[df["top25_ltv"] == 1][cols]
           .sort_values("ltv_realizado", ascending=False)
           .reset_index(drop=True))
    top.index += 1

    _write_df_to_sheet(ws, top, COLORS["header_verde"])

    # Destaca linhas de alto risco em vermelho
    if "risco_churn" in top.columns:
        for row_idx, risco in enumerate(top["risco_churn"], 2):
            if str(risco) == "Alto":
                fill = PatternFill("solid", fgColor=COLORS["vermelho_claro"])
                for col in range(1, len(cols) + 1):
                    ws.cell(row=row_idx, column=col).fill = fill


def sheet_full_scored(wb, df: pd.DataFrame):
    ws = wb.create_sheet("Base Completa Scored")
    ws.sheet_view.showGridLines = False

    export_cols = [c for c in [
        "id_cliente", "nome_clinica", "especialidade_principal", "uf",
        "porte_clinica", "canal_origem", "status",
        "dias_ativo", "maturidade_meses",
        "mrr_atual", "valor_addons", "ltv_realizado", "ltv_projetado",
        "ltv_quartil", "top25_ltv",
        "score_adocao_composto", "score_operacional",
        "score_financeiro", "score_jornada",
        "usa_ia", "usa_chatgds", "usa_conciliacao",
        "segmento", "segmento_rotulo",
        "score_churn", "risco_churn",
        "score_propensao_ds_pay", "score_propensao_ia", "score_propensao_chatgds",
        "num_pacientes_total", "faturamento_reconciliado",
    ] if c in df.columns]

    export_df = df[export_cols].copy()
    # Formata booleans
    for col in ["top25_ltv", "usa_ia", "usa_chatgds", "usa_conciliacao"]:
        if col in export_df.columns:
            export_df[col] = export_df[col].map({1: "Sim", 0: "Não"})

    _write_df_to_sheet(ws, export_df, COLORS["header_cinza"])


def sheet_segmentos(wb, perfil_df: pd.DataFrame):
    if perfil_df is None or len(perfil_df) == 0:
        return
    ws = wb.create_sheet("Segmentos ICP")
    ws.sheet_view.showGridLines = False
    _write_df_to_sheet(ws, perfil_df, COLORS["header_azul"])


def sheet_churn(wb, df: pd.DataFrame):
    ws = wb.create_sheet("Risco de Churn")
    ws.sheet_view.showGridLines = False

    if "risco_churn" not in df.columns:
        return

    ativos = df[df.get("churn", pd.Series(0, index=df.index)) == 0].copy()
    ativos_sorted = ativos.sort_values("score_churn", ascending=False)

    cols = [c for c in [
        "id_cliente", "nome_clinica", "especialidade_principal", "uf",
        "porte_clinica", "mrr_atual", "score_churn", "risco_churn",
        "score_adocao_composto", "maturidade_meses",
        "segmento_rotulo", "dias_ativo",
    ] if c in ativos_sorted.columns]

    export = ativos_sorted[cols].reset_index(drop=True)
    export.index += 1
    _write_df_to_sheet(ws, export, COLORS["header_laranja"])

    # Coloração por risco
    risco_col_idx = cols.index("risco_churn") + 1 if "risco_churn" in cols else None
    if risco_col_idx:
        for row_idx in range(2, len(export) + 2):
            cell_val = ws.cell(row=row_idx, column=risco_col_idx).value
            if cell_val == "Alto":
                fill = PatternFill("solid", fgColor="FCA5A5")
            elif cell_val == "Médio":
                fill = PatternFill("solid", fgColor="FDE68A")
            else:
                fill = PatternFill("solid", fgColor="BBF7D0")
            ws.cell(row=row_idx, column=risco_col_idx).fill = fill


def sheet_propensity(wb, priority_lists: dict):
    colors = {
        "DS Pay":      COLORS["header_roxo"],
        "Agentes IA":  COLORS["header_azul"],
        "ChatGDS":     COLORS["header_verde"],
    }
    for nome, top_df in priority_lists.items():
        sheet_name = f"Propensão {nome}"[:31]
        ws = wb.create_sheet(sheet_name)
        ws.sheet_view.showGridLines = False
        if len(top_df) > 0:
            _write_df_to_sheet(ws, top_df, colors.get(nome, COLORS["header_cinza"]))


def sheet_canal(wb, canal_data: dict):
    for subset_name, data in canal_data.items():
        if data is None or len(data) == 0:
            continue
        sheet_name = f"Canal — {subset_name}"[:31]
        ws = wb.create_sheet(sheet_name)
        ws.sheet_view.showGridLines = False
        _write_df_to_sheet(ws, data.reset_index(), COLORS["header_cinza"])


def sheet_coorte(wb, coorte: pd.DataFrame):
    if coorte is None or len(coorte) == 0:
        return
    ws = wb.create_sheet("Coorte de Retenção")
    ws.sheet_view.showGridLines = False
    _write_df_to_sheet(ws, coorte.reset_index(), COLORS["header_azul"])


def sheet_pricing(wb, tiers: pd.DataFrame):
    if tiers is None or len(tiers) == 0:
        return
    ws = wb.create_sheet("Tiers de Precificação")
    ws.sheet_view.showGridLines = False
    _write_df_to_sheet(ws, tiers.reset_index(), COLORS["header_verde"])


# ─────────────────────────────────────────────────────────────
# PIPELINE PRINCIPAL
# ─────────────────────────────────────────────────────────────
def run_report(df: pd.DataFrame, results: dict, meta: dict,
               perfil_df: pd.DataFrame = None,
               priority_lists: dict = None) -> str:
    """
    Gera o relatório Excel completo.
    Retorna o caminho do arquivo gerado.
    """
    print("\n" + "="*60)
    print("  MÓDULO 06 — RELATÓRIO EXCEL")
    print("="*60)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    import openpyxl
    wb = openpyxl.Workbook()
    # Remove sheet padrão
    wb.remove(wb.active)

    sheet_resumo(wb, df, results, meta)
    sheet_top_icp(wb, df, results.get("perfil_icp", {}))
    sheet_full_scored(wb, df)

    if perfil_df is not None:
        sheet_segmentos(wb, perfil_df)

    sheet_churn(wb, df)

    if priority_lists:
        sheet_propensity(wb, priority_lists)

    if "canais" in results and results["canais"]:
        sheet_canal(wb, results["canais"])

    if "coorte" in results and results["coorte"] is not None:
        sheet_coorte(wb, results["coorte"])

    if "pricing_tiers" in results and results["pricing_tiers"] is not None:
        sheet_pricing(wb, results["pricing_tiers"])

    wb.save(REPORT_PATH)
    print(f"✅ Relatório salvo: {REPORT_PATH}")
    print(f"   {len(wb.sheetnames)} abas geradas: {', '.join(wb.sheetnames)}")

    return REPORT_PATH


if __name__ == "__main__":
    print("Este módulo é chamado pelo run_pipeline.py")
